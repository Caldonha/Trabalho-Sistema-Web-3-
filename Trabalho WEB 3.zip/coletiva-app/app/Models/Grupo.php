<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\Produto;
use App\Models\Participacao;

class Grupo extends Model
{
    use HasFactory;

    protected $fillable = ['nome', 'descricao'];

    public function produtos()
    {
        return $this->hasMany(Produto::class);
    }

    public function participacoes()
    {
        return $this->hasMany(Participacao::class);
    }
}
