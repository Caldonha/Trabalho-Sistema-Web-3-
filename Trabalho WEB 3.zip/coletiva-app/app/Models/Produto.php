<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\Grupo;
use App\Models\Pedido;

class Produto extends Model
{
    use HasFactory;

    
    protected $fillable = ['nome', 'preco', 'grupo_id'];

    
    protected $casts = [
        'preco' => 'float',
    ];

    public function grupo()
    {
        return $this->belongsTo(Grupo::class);
    }

    public function pedidos()
    {
        return $this->hasMany(Pedido::class);
    }
}
